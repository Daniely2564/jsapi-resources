<script setup>
import ArcadeEditor from "@/components/ArcadeEditor.vue";
</script>

<template>
  <ArcadeEditor />
</template>
