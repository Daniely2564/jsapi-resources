#!/usr/bin/env bash
deno run --allow-net --allow-env --allow-read request.ts
